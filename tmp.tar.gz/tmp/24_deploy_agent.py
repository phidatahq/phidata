from pathlib import Path

from phi.agent import Agent
from phi.model.openai import OpenAIChat
from phi.storage.agent.sqlite import SqlAgentStorage
from phi.tools.duckduckgo import DuckDuckGo
from phi.playground import Playground, deploy_playground_app

web_agent = Agent(
    name="Web Agent",
    model=OpenAIChat(id="gpt-4o"),
    tools=[DuckDuckGo()],
    instructions=["Always include sources"],
    storage=SqlAgentStorage(table_name="web_agent", db_file="agents.db"),
    add_history_to_messages=True,
    markdown=True,
    debug_mode=True,
)

app = Playground(agents=[web_agent]).get_app()

if __name__ == "__main__":
    deploy_playground_app(app="24_deploy_agent:app", name="agent-test", root=Path(__file__).parent)
