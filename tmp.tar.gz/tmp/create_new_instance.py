"""Run `pip install yfinance exa_py` to install dependencies."""

from phi.agent import Agent, AgentMemory, Message
from phi.model.openai import OpenAIChat
from phi.memory.db.postgres import PgMemoryDb
from phi.storage.agent.postgres import PgAgentStorage
from phi.tools.yfinance import YFinanceTools
from phi.knowledge.pdf import PDFUrlKnowledgeBase
from phi.vectordb.pgvector import PgVector, SearchType

from phi.utils.log import logger

db_uri = "tmp/lancedb"
db_url: str = "postgresql+psycopg://ai:ai@localhost:5532/ai"

agent_1 = Agent(
    name="Agent 1",
    agent_id="agent-1",
    model=OpenAIChat(id="gpt-4o"),
    tools=[YFinanceTools(enable_all_tools=True)],
    instructions=["Use tables where possible"],
    show_tool_calls=True,
    markdown=True,
    agent_data={},
    knowledge_base=PDFUrlKnowledgeBase(
        urls=["https://phi-public.s3.amazonaws.com/recipes/ThaiRecipes.pdf"],
        vector_db=PgVector(table_name="recipes", db_url=db_url, search_type=SearchType.hybrid),
    ),
    debug_mode=True,
    add_history_to_messages=True,
    description="You are a finance agent",
    add_datetime_to_instructions=True,
    storage=PgAgentStorage(table_name="finance_agent_sessions", db_url=db_url),
    memory=AgentMemory(
        db=PgMemoryDb(table_name="agent_memory", db_url=db_url), create_user_memories=True, create_session_summary=True
    ),
)

logger.info("-*- Agent 1")
agent_1.model.metrics = {"accuracy": 0.9}
agent_1.memory.messages = [Message(content="Hello, how can I help you?", role="agent")]
logger.info(f"agent_1.agent_id: {agent_1.agent_id}")
logger.info(f"agent_1.session_id: {agent_1.session_id}")
logger.info(f"agent_1.model.metrics: {agent_1.model.metrics}")
logger.info(f"agent_1.memory.messages: {agent_1.memory.messages}")

logger.info("-*- Agent 2")
agent_2 = agent_1.create_copy()
logger.info(f"agent_2.agent_id: {agent_2.agent_id}")
logger.info(f"agent_2.session_id: {agent_2.session_id}")
logger.info(f"agent_2.model.metrics: {agent_2.model.metrics}")
logger.info(f"agent_2.memory.messages: {agent_2.memory.messages}")

logger.info("\n")
logger.info("-*- Comparing agent_1 and agent_2 ids")

# Compare ids of agent_1 and agent_2
logger.info(f"id(agent_1) == id(agent_2): {id(agent_1) == id(agent_2)}")

# List of attributes to compare
attributes = agent_1.model_fields

# Compare ids of agent_1 and agent_2 attributes
for attr in attributes:
    attr1 = getattr(agent_1, attr)
    attr2 = getattr(agent_2, attr)
    same_id = id(attr1) == id(attr2)
    logger.info(f"id(agent_1.{attr}) == id(agent_2.{attr}): {same_id}")

# Compare ids of nested attributes
logger.info("\n- Comparing nested attributes")

# Compare model.metrics
logger.info(f"id(agent_1.model.metrics) == id(agent_2.model.metrics): {id(agent_1.model.metrics) == id(agent_2.model.metrics)}")

# Compare memory.messages
logger.info(f"id(agent_1.memory.messages) == id(agent_2.memory.messages): {id(agent_1.memory.messages) == id(agent_2.memory.messages)}")

# Compare contents of memory.messages
logger.info(f"agent_1.memory.messages == agent_2.memory.messages: {agent_1.memory.messages == agent_2.memory.messages}")

logger.info("\n- Modifying agent_2 data to test independence")

# Modify agent_2's data
agent_2.name = "Agent 2"
agent_2.model.metrics['accuracy'] = 0.95
agent_2.memory.messages.append(Message(content="This is agent 2", role="agent"))

# Check if agent_1 remains unchanged
logger.info(f"agent_1.name: {agent_1.name}")
logger.info(f"agent_2.name: {agent_2.name}")

logger.info(f"agent_1.model.metrics: {agent_1.model.metrics}")
logger.info(f"agent_2.model.metrics: {agent_2.model.metrics}")

logger.info(f"agent_1.memory.messages: {agent_1.memory.messages}")
logger.info(f"agent_2.memory.messages: {agent_2.memory.messages}")
