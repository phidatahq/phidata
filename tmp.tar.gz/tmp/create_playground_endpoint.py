from phi.agent import Agent
from phi.playground import Playground

playground = Playground(agents=[Agent()])
playground.create_endpoint("http://localhost:8000")
