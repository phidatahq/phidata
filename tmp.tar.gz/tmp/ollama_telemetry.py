import asyncio

from phi.agent import Agent
from phi.model.ollama import Ollama
from phi.tools.yfinance import YFinanceTools
from phi.storage.agent.postgres import PgAgentStorage

agent = Agent(
    model=Ollama(id="llama3.2"),
    tools=[YFinanceTools(stock_price=True)],
    show_tool_calls=True,
    markdown=True,
    debug_mode=True,
    description="You are an investment analyst that researches stocks and helps users make informed decisions.",
    instructions=["Use tables to display data where possible."],
    storage=PgAgentStorage(table_name="agent_sessions", db_url="postgresql+psycopg://ai:ai@localhost:5532/ai"),
)


async def main():
    await agent.aprint_response("What is the stock price of NVDA and TSLA")
    await agent.aprint_response("What is the stock price of NVDA and TSLA", stream=True)


asyncio.run(main())

agent.print_response("What is the stock price of NVDA and TSLA?")
agent.print_response("What is the stock price of NVDA and TSLA?", stream=True)
